from flask import Blueprint, render_template, redirect, url_for
from flask_login import login_required, current_user
from datetime import datetime, date
from app.models.cliente import Cliente, Servicio
from app.models.transaccion import Transaccion
from sqlalchemy import func, and_
from app.extensions import db

main = Blueprint('main', __name__)

# Función auxiliar para manejar fechas de forma segura
def safe_strftime(fecha_obj, formato='%Y-%m-%d'):
    """Convierte una fecha a string de forma segura.
    Si fecha_obj ya es string, lo devuelve tal cual.
    Si es un objeto datetime o date, aplica strftime con el formato indicado."""
    if isinstance(fecha_obj, str):
        return fecha_obj
    elif isinstance(fecha_obj, (datetime, date)):
        return fecha_obj.strftime(formato)
    return str(fecha_obj)  # En caso de otro tipo, convertir a string

@main.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    return render_template('index.html', now=datetime.now())

@main.route('/dashboard')
@login_required
def dashboard():
    # Obtener conteo total de clientes
    clientes_count = Cliente.query.count()
    
    # Obtener transacciones realizadas hoy
    hoy = date.today()
    transacciones_hoy = Transaccion.query.filter(
        func.date(Transaccion.fecha) == hoy
    ).count()
    
    # Obtener clientes cercanos al límite (con saldo disponible < 100)
    clientes_limite_ids = []
    clientes = Cliente.query.all()
    for cliente in clientes:
        if cliente.calcular_saldo_disponible() < 100:
            clientes_limite_ids.append(cliente.id)
    
    clientes_limite = len(clientes_limite_ids)
    
    # Obtener clientes recientes (últimos 5 con actividad)
    clientes_recientes = Cliente.query.order_by(Cliente.ultima_visita.desc()).limit(5).all()
    
    # Obtener servicios disponibles
    servicios = Servicio.query.all()
    
    # Estadísticas de documentos
    from app.models.documento import DocumentoCliente
    try:
        stats_docs = DocumentoCliente.contar_por_estado()
        docs_vencidos = stats_docs.get('vencidos', 0)
        docs_por_vencer = stats_docs.get('por_vencer', 0)
    except:
        docs_vencidos = 0
        docs_por_vencer = 0
    
    # En una versión futura, se pueden implementar notificaciones
    notificaciones = []
    
    return render_template('dashboard.html', 
                          now=datetime.now(),
                          clientes_count=clientes_count,
                          transacciones_hoy=transacciones_hoy,
                          clientes_limite=clientes_limite,
                          clientes_recientes=clientes_recientes,
                          servicios=servicios,
                          notificaciones=notificaciones,
                          docs_vencidos=docs_vencidos,
                          docs_por_vencer=docs_por_vencer)

