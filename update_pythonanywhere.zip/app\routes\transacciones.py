from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app.models.cliente import Cliente, Servicio
from app.models.transaccion import Transaccion
from app import db
from datetime import datetime, timedelta
from sqlalchemy import func, desc

transacciones = Blueprint('transacciones', __name__)

@transacciones.route('/')
@login_required
def lista():
    transacciones = Transaccion.query.order_by(Transaccion.fecha.desc()).all()
    
    # Estadísticas rápidas
    # Fechas para filtrados
    hoy = datetime.now().date()
    inicio_semana = hoy - timedelta(days=hoy.weekday())
    inicio_mes = datetime(hoy.year, hoy.month, 1).date()
    
    # Transacciones del día
    transacciones_hoy = Transaccion.query.filter(
        func.date(Transaccion.fecha) == hoy
    ).all()
    
    # Transacciones de la semana
    transacciones_semana = Transaccion.query.filter(
        func.date(Transaccion.fecha) >= inicio_semana
    ).all()
    
    # Transacciones del mes
    transacciones_mes = Transaccion.query.filter(
        func.date(Transaccion.fecha) >= inicio_mes
    ).all()
    
    # Cálculo de montos
    monto_total_hoy = sum(t.monto for t in transacciones_hoy)
    comision_total_hoy = sum(t.comision for t in transacciones_hoy)
    
    monto_total_semana = sum(t.monto for t in transacciones_semana)
    comision_total_semana = sum(t.comision for t in transacciones_semana)
    
    monto_total_mes = sum(t.monto for t in transacciones_mes)
    comision_total_mes = sum(t.comision for t in transacciones_mes)
    
    # Top clientes frecuentes (últimos 30 días)
    fecha_limite = hoy - timedelta(days=30)
    clientes_frecuentes = db.session.query(
        Cliente,
        func.count(Transaccion.id).label('total_transacciones')
    ).join(Transaccion).filter(
        func.date(Transaccion.fecha) >= fecha_limite
    ).group_by(
        Cliente.id
    ).order_by(
        desc('total_transacciones')
    ).limit(5).all()
    
    estadisticas = {
        'transacciones_hoy': len(transacciones_hoy),
        'transacciones_semana': len(transacciones_semana),
        'transacciones_mes': len(transacciones_mes),
        'monto_total_hoy': monto_total_hoy,
        'comision_total_hoy': comision_total_hoy,
        'monto_total_semana': monto_total_semana,
        'comision_total_semana': comision_total_semana,
        'monto_total_mes': monto_total_mes,
        'comision_total_mes': comision_total_mes,
        'clientes_frecuentes': clientes_frecuentes
    }
    
    return render_template('transacciones/lista.html', 
                          transacciones=transacciones,
                          estadisticas=estadisticas,
                          now=datetime.now())

@transacciones.route('/cliente/<int:cliente_id>')
@login_required
def cliente_historial(cliente_id):
    cliente = Cliente.query.get_or_404(cliente_id)
    transacciones = Transaccion.query.filter_by(cliente_id=cliente_id).order_by(Transaccion.fecha.desc()).all()
    saldo_disponible = cliente.calcular_saldo_disponible()
    dias_reestablecimiento = cliente.dias_hasta_reestablecimiento()
    
    return render_template('transacciones/cliente_historial.html', 
                          cliente=cliente, 
                          transacciones=transacciones,
                          saldo_disponible=saldo_disponible,
                          dias_reestablecimiento=dias_reestablecimiento,
                          now=datetime.now())

@transacciones.route('/nueva', methods=['GET', 'POST'])
@login_required
def nueva():
    # Si llega con un cliente preseleccionado
    cliente_id = request.args.get('cliente_id', None)
    cliente = None
    
    if cliente_id:
        cliente = Cliente.query.get_or_404(cliente_id)
    
    if request.method == 'POST':
        # Obtener datos del formulario
        cliente_id = request.form.get('cliente_id')
        servicio_id = request.form.get('servicio_id')
        monto = request.form.get('monto')
        comision = request.form.get('comision')
        descripcion = request.form.get('descripcion')
        
        # Validaciones
        if not cliente_id or not servicio_id or not monto:
            flash('Todos los campos con * son obligatorios', 'danger')
            return redirect(url_for('transacciones.nueva', cliente_id=cliente_id))
        
        # Convertir valores numéricos
        try:
            monto = float(monto)
            comision = float(comision) if comision else 0
        except ValueError:
            flash('Los montos deben ser valores numéricos válidos', 'danger')
            return redirect(url_for('transacciones.nueva', cliente_id=cliente_id))
        
        # Verificar cliente y servicio
        cliente = Cliente.query.get(cliente_id)
        servicio = Servicio.query.get(servicio_id)
        
        if not cliente or not servicio:
            flash('Cliente o servicio no válido', 'danger')
            return redirect(url_for('transacciones.nueva'))
        
        # Verificar límite de transacciones
        saldo_disponible = cliente.calcular_saldo_disponible()
        if monto > saldo_disponible:
            flash(f'El monto excede el límite disponible de {saldo_disponible}€ para este cliente', 'danger')
            return redirect(url_for('transacciones.nueva', cliente_id=cliente_id))
        
        # Crear transacción
        nueva_transaccion = Transaccion(
            cliente_id=cliente_id,
            servicio_id=servicio_id,
            monto=monto,
            comision=comision,
            notas=descripcion,
            fecha=datetime.now(),
            creado_por=current_user.id
        )
        
        db.session.add(nueva_transaccion)
        
        # Actualizar última visita del cliente
        cliente.ultima_visita = datetime.now()
        
        db.session.commit()
        flash('Transacción registrada correctamente', 'success')
        
        # Redireccionar al historial del cliente
        return redirect(url_for('transacciones.cliente_historial', cliente_id=cliente_id))
    
    # GET: Mostrar formulario
    clientes = Cliente.query.all()
    servicios = Servicio.query.all()
    
    # Si hay un cliente preseleccionado, calculamos su saldo disponible
    saldo_disponible = None
    if cliente:
        saldo_disponible = cliente.calcular_saldo_disponible()
    
    return render_template('transacciones/nueva.html', 
                          clientes=clientes, 
                          servicios=servicios, 
                          cliente_seleccionado=cliente,
                          saldo_disponible=saldo_disponible,
                          now=datetime.now())

@transacciones.route('/editar/<int:transaccion_id>', methods=['GET', 'POST'])
@login_required
def editar(transaccion_id):
    # Obtener la transacción existente
    transaccion = Transaccion.query.get_or_404(transaccion_id)
    
    # Si es un POST, actualizar la transacción
    if request.method == 'POST':
        # Obtener datos del formulario
        servicio_id = request.form.get('servicio_id')
        monto = request.form.get('monto')
        comision = request.form.get('comision')
        descripcion = request.form.get('descripcion')
        
        # Validaciones
        if not servicio_id or not monto:
            flash('Todos los campos con * son obligatorios', 'danger')
            return redirect(url_for('transacciones.editar', transaccion_id=transaccion_id))
        
        # Convertir valores numéricos
        try:
            monto = float(monto)
            comision = float(comision) if comision else 0
        except ValueError:
            flash('Los montos deben ser valores numéricos válidos', 'danger')
            return redirect(url_for('transacciones.editar', transaccion_id=transaccion_id))
        
        # Verificar servicio
        servicio = Servicio.query.get(servicio_id)
        
        if not servicio:
            flash('Servicio no válido', 'danger')
            return redirect(url_for('transacciones.editar', transaccion_id=transaccion_id))
        
        # Actualizar transacción
        transaccion.servicio_id = servicio_id
        transaccion.monto = monto
        transaccion.comision = comision
        transaccion.notas = descripcion
        
        db.session.commit()
        flash('Transacción actualizada correctamente', 'success')
        
        # Redireccionar al historial del cliente
        return redirect(url_for('transacciones.cliente_historial', cliente_id=transaccion.cliente_id))
    
    # GET: Mostrar formulario con datos de la transacción
    servicios = Servicio.query.all()
    
    return render_template('transacciones/editar.html', 
                          transaccion=transaccion,
                          servicios=servicios,
                          now=datetime.now())
